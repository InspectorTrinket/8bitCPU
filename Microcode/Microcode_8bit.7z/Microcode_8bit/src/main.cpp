// ROM to be programmed
#define ROM_NO 0

// Programming tasks (cannot be done all at once due to Arduino Nano's lack of RAM)
//#define INS_MOV 1
//#define INS_LOD 1
//#define INS_STO 1
//#define INS_ALU 1
//#define INS_ALU_SP 1  // Special ALU instructions: adds all ALU functions to the Stack Pointer Register (converts the SP into a general purpose register). Must be programmed AFTER the LOD instructions, taking up the unused space.

// Other options (CHECK COVERAGE does not work for the ALU instructions due to Arduino Nano's lack of RAM)
#define ERASE 1
#define DUMP 1
//#define CHECK_COVERAGE 1

#include <Arduino.h>
#include <EEPROG.h> 
#include <stdint.h>

// EEPROM data lines:  bit position     23   22   21   20   19   18   17   16   15   14   13   12   11   10    9    8    7    6    5 .. 3    2 .. 0
//                     meaning           -    -    -    - _PRM  PCe  RMi  RMo  S04  S03  S02  S01  S00 _HLT _ALi _Cin _uCL _MAi MPlex_out  MPlex_in

// Multiplexed Inputs
#define _RAi (uint32_t) 1      // A Register In            inv 110 = 001 = 1
#define _RBi (uint32_t) 2      // B Register In            inv 101 = 010 = 2
#define _RCi (uint32_t) 3      // C Register In            inv 100 = 011 = 3
#define _RDi (uint32_t) 4      // D Register In            inv 011 = 100 = 4
#define _PCi (uint32_t) 5      // Program Counter In       inv 010 = 101 = 5
#define _SPi (uint32_t) 6      // Stack Pointer In         inv 001 = 110 = 6
#define _IRi (uint32_t) 7      // Instruction Register In  inv 000 = 111 = 7

// Multiplexed Outputs
#define _RAo (uint32_t) 8      // A Register Out           inv 110111 = 001000 = 8
#define _RBo (uint32_t) 16     // B Register Out           inv 101111 = 010000 = 16
#define _RCo (uint32_t) 24     // C Register Out           inv 100111 = 011000 = 24
#define _RDo (uint32_t) 32     // D Register Out           inv 011111 = 100000 = 32
#define _PCo (uint32_t) 40     // Program Counter Out      inv 010111 = 101000 = 40
#define _SPo (uint32_t) 48     // Stack Pointer Out        inv 001111 = 110000 = 48
#define _ALo (uint32_t) 56     // ALU Register Out         inv 000111 = 111000 = 56

#define _MPXaddr (uint32_t) 63 // Multiplexed address range    111111 = 63

// Direct Signals
//#define _Mx0 (uint32_t)1 << 0  // Multiplexer address line
//#define _Mx1 (uint32_t)1 << 1  // Multiplexer address line
//#define _Mx2 (uint32_t)1 << 2  // Multiplexer address line
//#define _Mx3 (uint32_t)1 << 3  // Multiplexer address line
//#define _Mx4 (uint32_t)1 << 4  // Multiplexer address line
//#define _Mx5 (uint32_t)1 << 5  // Multiplexer address line
#define _MAi (uint32_t)1 << 6  // Memory Address Register In
#define _uCL (uint32_t)1 << 7  // Microtime Clear
#define _Cin (uint32_t)1 << 8  // Carry In
#define _ALi (uint32_t)1 << 9  // ALU Register In
#define _HLT (uint32_t)1 << 10 // HALT
//#define S00 (uint32_t)1 << 11  // ALU S0
//#define S01 (uint32_t)1 << 12  // ALU S1
//#define S02 (uint32_t)1 << 13  // ALU S2
//#define S03 (uint32_t)1 << 14  // ALU S3
//#define S04 (uint32_t)1 << 15  // ALU Logic Function Select
#define RMo (uint32_t)1 << 16  // RAM Out
#define RMi (uint32_t)1 << 17  // RAM In
#define PCe (uint32_t)1 << 18  // Program Couter Enable
#define _PrM (uint32_t)1 << 19 // Program Memory Access

#define ALS(S) ((uint32_t)S << 11) // ALU Signal function

// ALU S4 to S0 Words
#define INC_A     0b00000
#define A_MINUS_B 0b00110
#define A_PLUS_B  0b01001
#define SHL_A     0b01100
#define DCR_A     0b01111
#define NOT_A     0b10000
#define ZERO_0    0b10011
#define ONE_0     0b11100
#define A_XOR_B   0b10110
#define A_AND_B   0b11011
#define A_OR_B    0b11110

// EEPROM address:  bit position     12       11      10  ....   8      7   .....    0
//                  meaning       carry    flags     (microtime) T              opcode

// EEPROM address function
#define FLAGS_ADDR (1 << 11)
#define CARRY_ADDR (1 << 12)
#define ins_eeprom_address(opcode, carry, flags, T) (opcode | (carry ? CARRY_ADDR : 0) | (flags ? FLAGS_ADDR : 0) | (T << 8))

// Register definition
#define Ra   0b000
#define Rb   0b001
#define Rc   0b010
#define Rd   0b011
#define Sp   0b100
#define Pc   0b101
#define SPid 0b110
#define IMM  0b111

// Intruction types
#define MOV 0b00
#define LOD 0b01
#define STO 0b10

// ALU Function codes
#define INC  0b0000
#define SHL  0b0001
#define SUB  0b0010
#define ADD  0b0011
#define XOR  0b0100
#define OR   0b0101
#define AND  0b0110
#define NOT  0b0111
#define DCR  0b1000
#define ROL  0b1001
#define SUBC 0b1010
#define ADDC 0b1011
#define ZERO 0b1100
#define ONE  0b1101
#define CMP  0b1110
#define TST  0b1111

// OPCODE formation function
#define OPCODE(op,dreg,sreg) (((op) << 6) | ((dreg) << 3) | (sreg))
#define ALU_OPCODE(Fcode,reg) ((0b11 << 6) | (Fcode << 2) | (reg & 0b11))

// Microcode output WORD bit flipping for active LOWs
uint32_t inline flip_active_lows(uint32_t microcode_word) {

  microcode_word ^= (_MPXaddr | _MAi	| _uCL | _Cin | _ALi | _HLT | _PrM);
  return microcode_word;
}

// Convenience switches for programming
uint32_t _OUT(uint32_t reg) {
  switch (reg) {
    case Ra: return _RAo;
    case Rb: return _RBo;
    case Rc: return _RCo;
    case Rd: return _RDo;
    case Sp: return _SPo;
    case Pc: return _PCo;
        default: return 0; 
  }
}
uint32_t _IN(uint32_t reg) {
  switch (reg) {
    case Ra: return _RAi;
    case Rb: return _RBi;
    case Rc: return _RCi;
    case Rd: return _RDi;
    case Sp: return _SPi;
    case Pc: return _PCi;
    default: return 0; 
  }
}

// Microcode base instruction
#define FETCH0 (_PCo | _MAi)
#define FETCH1 (_PrM | RMo | _IRi | PCe)
uint32_t microcode[8] = {FETCH0,FETCH1,_uCL,0,0,0,0,0};

// Variable microcode lenght
uint32_t *MICROCODE0() {
  microcode[2] = _uCL;
  microcode[3] = microcode[4] = microcode[5] = microcode[6] = microcode[7] = 0;
  return microcode;
}
uint32_t *MICROCODE1(uint32_t c1) {
  microcode[2] = c1 | _uCL;
  microcode[3] = microcode[4] = microcode[5] = microcode[6] = microcode[7] = 0;
  return microcode;
}
uint32_t *MICROCODE2(uint32_t c1, uint32_t c2) {
  microcode[2] = c1;
  microcode[3] = c2 | _uCL;
  microcode[4] = microcode[5] = microcode[6] = microcode[7] = 0;
  return microcode;
}
uint32_t *MICROCODE3(uint32_t c1,uint32_t c2,uint32_t c3) {
  microcode[2] = c1;
  microcode[3] = c2;
  microcode[4] = c3 | _uCL;
  microcode[5] = microcode[6] = microcode[7] = 0;
  return microcode;
}
uint32_t *MICROCODE4(uint32_t c1,uint32_t c2,uint32_t c3, uint32_t c4) {
  microcode[2] = c1;
  microcode[3] = c2;
  microcode[4] = c3;
  microcode[5] = c4 | _uCL;
  microcode[6] = microcode[7] = 0;
  return microcode;
}

#ifdef CHECK_COVERAGE
uint8_t write_mask[32];
#endif

// EEPROM writting
void write_conditional_instruction(uint16_t opcode, bool carry, bool flags, uint32_t microcode[], uint8_t rom_no) {
  for (uint8_t T = 0; T < 8; T++) {
    uint16_t eeprom_address = ins_eeprom_address(opcode, carry, flags, T);
    uint8_t eeprom_byte = (flip_active_lows(microcode[T]) >> (8*rom_no)) & 0xFF;
    EEPROG.writeEEPROM(eeprom_address, eeprom_byte);
    
    #ifdef CHECK_COVERAGE
    uint8_t bit_no = eeprom_address & 0x7;
    write_mask[(eeprom_address & 0xFF) >> 3] |= (1 << bit_no);
    #endif
  }
}
void write_carrycond_instruction(uint16_t opcode, bool carry, uint32_t microcode[], uint8_t rom_no) {
  write_conditional_instruction(opcode, carry, false, microcode, rom_no);
  write_conditional_instruction(opcode, carry, true, microcode, rom_no);
}
void write_instruction(uint16_t opcode, uint32_t microcode[], uint8_t rom_no) {
  write_carrycond_instruction(opcode, false, microcode, rom_no);
  write_carrycond_instruction(opcode, true, microcode, rom_no);
}

// Programming the MOV instructions
#ifdef INS_MOV 
void write_MOVs(uint8_t rom_no) {
  Serial.print("Writing reg <- reg MOV instructions .");
  for (uint8_t sreg = Ra; sreg <= Pc; sreg++) {
    Serial.print(".");
    for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
      if (sreg != dreg) {
        write_instruction(OPCODE(MOV, dreg, sreg), MICROCODE1(_IN(dreg) | _OUT(sreg)), rom_no);
      }
    }
  }
  Serial.println(" done.");
  Serial.print("Writing reg <- imm DATA instructions .");
    for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
      write_instruction(OPCODE(MOV, dreg, IMM), MICROCODE2(_PCo | _MAi | PCe, _PrM | RMo | _IN(dreg)), rom_no);
    }
  Serial.println(". done.");
  Serial.print("Writing NOP and HLT .");
  write_instruction(OPCODE(MOV, Ra, Ra), MICROCODE0(), rom_no);
  write_instruction(OPCODE(MOV, Pc, Pc), MICROCODE1(_HLT), rom_no);
  Serial.println(". done.");
  Serial.print("Writing conditional JC, JZ, JO and JN instructions .");
  write_carrycond_instruction(OPCODE(MOV, IMM, 0b000), false, MICROCODE1(PCe), rom_no);                                 //JC false
  write_carrycond_instruction(OPCODE(MOV, IMM, 0b000), true, MICROCODE2(_PCo | _MAi | PCe, _PrM | RMo | _PCi), rom_no); //JC true
  Serial.print(".");
    for (uint8_t flag = 1; flag <= 3; flag++) {
    write_conditional_instruction(OPCODE(MOV, IMM, flag), false, false, MICROCODE1(PCe), rom_no);
    write_conditional_instruction(OPCODE(MOV, IMM, flag), true, false, MICROCODE1(PCe), rom_no);
    write_conditional_instruction(OPCODE(MOV, IMM, flag), false, true, MICROCODE2(_PCo | _MAi | PCe, _PrM | RMo | _PCi), rom_no);
    write_conditional_instruction(OPCODE(MOV, IMM, flag), true, true, MICROCODE2(_PCo | _MAi | PCe, _PrM | RMo | _PCi), rom_no);
    Serial.print(".");
  }
  Serial.println(". done.");
  Serial.println("42 MOV instructions written.");
  Serial.print("Writing HLT to currently unused opcodes (22 total): MOV IMM, Sp|Pc|SPid|IMM (4)  |  MOV SPid, <any_R>|SPid|IMM (8) | MOV <any_R>, SPid (6) | MOV <any_R>, <thesame_R> (except Ra, PC) (4) .");
  write_instruction(OPCODE(MOV, IMM, Sp), MICROCODE1(_HLT), rom_no);
  write_instruction(OPCODE(MOV, IMM, Pc), MICROCODE1(_HLT), rom_no);
  write_instruction(OPCODE(MOV, IMM, SPid), MICROCODE1(_HLT), rom_no);
  write_instruction(OPCODE(MOV, IMM, IMM), MICROCODE1(_HLT), rom_no);
  Serial.print(".");
  for (uint8_t sreg = Ra; sreg <= IMM; sreg++) {
    write_instruction(OPCODE(MOV, SPid, sreg), MICROCODE1(_HLT), rom_no);
  }
  Serial.print(".");
  for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
    write_instruction(OPCODE(MOV, dreg, SPid), MICROCODE1(_HLT), rom_no);
  }
  Serial.print(".");
  for (uint8_t reg = Rb; reg <= Sp; reg++) {
    write_instruction(OPCODE(MOV, reg, reg), MICROCODE1(_HLT), rom_no);    
  }
  Serial.println(". done.");
}
#endif

// Programming the LOD instructions (must be done AFTER the LOD instructions)
#ifdef INS_LOD
void write_LODs(uint8_t rom_no) {
  Serial.print("Writing reg <- [reg] LOD instructions .");
  for (uint8_t sreg = Ra; sreg <= Pc; sreg++) {
    Serial.print(".");
    for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
      write_instruction(OPCODE(LOD, dreg, sreg), MICROCODE2(_MAi | _OUT(sreg), ((sreg == Rc) ? _PrM : 0) | RMo | _IN(dreg)), rom_no);
    }
  }
  Serial.println(" done.");
  Serial.print("Writing reg <- [SPid] POP instructions .");
  for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
    write_instruction(OPCODE(LOD, dreg, SPid), MICROCODE3(_SPo | _ALi | _Cin | ALS(INC_A) | _MAi,  _SPi | _ALo, _IN(dreg) | RMo), rom_no); 
  }
  Serial.println(". done.");
  Serial.print("Writing reg <- [IMM] LOD instructions .");
  for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
    write_instruction(OPCODE(LOD, dreg, IMM), MICROCODE3(_MAi | _PCo | PCe, RMo | _PrM | _MAi, RMo | _IN(dreg)), rom_no); 
  }  
  Serial.println(". done.");
  Serial.println("48 LOD instructions written.");
  Serial.print("Writing HLT to currently unused opcodes (16 total): STO [<any_R>|SPid|IMM] <- IMM (8)  |  STO [<any_R>|SPid|IMM] <- SPid (8) ");
  for (uint8_t sreg = SPid; sreg <= IMM; sreg++) {
    for (uint8_t dreg = Ra; dreg <= IMM; dreg++) {
      write_instruction(OPCODE(STO, dreg, sreg), MICROCODE1(_HLT), rom_no); 
    }
    Serial.print(".");
  }  
  Serial.println(" done.");
}
#endif

// Programming the STO instructions
#ifdef INS_STO
void write_STOs(uint8_t rom_no) {
  Serial.print("Writing [reg] <- reg STO instructions .");
  for (uint8_t sreg = Ra; sreg <= Pc; sreg++) {
    Serial.print(".");
    for (uint8_t dreg = Ra; dreg <= Pc; dreg++) {
      write_instruction(OPCODE(STO, dreg, sreg), MICROCODE2(_MAi | _OUT(dreg), RMi | _OUT(sreg)), rom_no);
    }
  }
  Serial.println(" done.");
  Serial.print("Writing [SPid] <- reg PUSH instructions .");
  for (uint8_t sreg = Ra; sreg <= Sp; sreg++) {
    write_instruction(OPCODE(STO, SPid, sreg), MICROCODE3(_SPo | _ALi | ALS(DCR_A), _SPi | _ALo | _MAi, _OUT(sreg) | RMi), rom_no); 
  }
  Serial.println(". done.");
  Serial.print("Writing CALL instruction .");
    write_instruction(OPCODE(STO, SPid, Pc), MICROCODE4(_SPo | _ALi | ALS(DCR_A), _SPi | _ALo | _MAi, _PCo | RMi, _PCi | _RCo), rom_no);
  Serial.println(". done.");
  Serial.print("Writing [IMM] <- reg STO instructions .");
  for (uint8_t sreg = Ra; sreg <= Pc; sreg++) {
    write_instruction(OPCODE(STO, IMM, sreg), MICROCODE3(_MAi | _PCo | PCe, RMo | _PrM | _MAi, RMi | _OUT(sreg)), rom_no);
  }
  Serial.println(". done.");
  Serial.println("48 STO instructions written.");
  Serial.print("Writing HLT to currently unused opcodes (16 total): STO [<any_R>|SPid|IMM] <- IMM (8)  |  STO [<any_R>|SPid|IMM] <- SPid (8) ");
  for (uint8_t sreg = SPid; sreg <= IMM; sreg++) {
    for (uint8_t dreg = Ra; dreg <= IMM; dreg++) {
      write_instruction(OPCODE(STO, dreg, sreg), MICROCODE1(_HLT), rom_no); 
    }
    Serial.print(".");
  }  
  Serial.println(" done.");
}
#endif

// Programming the ALU instructions
#ifdef INS_ALU
void write_ALU_instructions(uint8_t rom_no) {
  Serial.print("Writing INC reg <- reg + 1 and DCR reg <- reg - 1 instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(INC, reg), MICROCODE2(_OUT(reg) | ALS(INC_A) | _Cin | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.print(".");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(DCR, reg), MICROCODE2(_OUT(reg) | ALS(DCR_A) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing SHL|ROL reg <- reg instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(SHL, reg), MICROCODE2(_OUT(reg) | ALS(SHL_A) | _ALi, _IN(reg) | _ALo), rom_no);
    write_carrycond_instruction(ALU_OPCODE(ROL, reg), false, MICROCODE3(_OUT(reg) | ALS(SHL_A) | _ALi, _OUT(reg) | ALS(SHL_A) | _ALi, _IN(reg) | _ALo), rom_no); //The first uTime tests the existence of a carry for the ROL operation. If present, the execution changes to the instruction below. 
    write_carrycond_instruction(ALU_OPCODE(ROL, reg), true, MICROCODE3(_OUT(reg) | ALS(SHL_A) | _ALi, _OUT(reg) | ALS(SHL_A) | _Cin | _ALi, _IN(reg) | _ALo), rom_no); //The first uTime tests the existence of a carry for the ROL operation. If not present, the execution changes to the instruction above.  
  }
  Serial.println(". done.");
  Serial.print("Writing ADD|ADDC reg <- reg + Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(ADD, reg), MICROCODE2(_OUT(reg) | ALS(A_PLUS_B) | _ALi, _IN(reg) | _ALo), rom_no);
    write_carrycond_instruction(ALU_OPCODE(ADDC, reg), false, MICROCODE2(_OUT(reg) | ALS(A_PLUS_B) | _ALi, _IN(reg) | _ALo), rom_no);
    write_carrycond_instruction(ALU_OPCODE(ADDC, reg), true, MICROCODE2(_OUT(reg) | ALS(A_PLUS_B) | _Cin | _ALi, _IN(reg) | _ALo), rom_no);    
  }
  Serial.println(". done.");
  Serial.print("Writing SUB|SUBC reg <- reg - Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(SUB, reg), MICROCODE2(_OUT(reg) | ALS(A_MINUS_B) | _Cin | _ALi, _IN(reg) | _ALo), rom_no);
    write_carrycond_instruction(ALU_OPCODE(SUBC, reg), false, MICROCODE2(_OUT(reg) | ALS(A_MINUS_B) | _ALi, _IN(reg) | _ALo), rom_no);
    write_carrycond_instruction(ALU_OPCODE(SUBC, reg), true, MICROCODE2(_OUT(reg) | ALS(A_MINUS_B) | _Cin | _ALi, _IN(reg) | _ALo), rom_no);     
  }
  Serial.println(". done.");
  Serial.print("Writing CMP reg, Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(CMP, reg), MICROCODE1(_OUT(reg) | ALS(A_MINUS_B) | _ALi), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing TST reg instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(TST, reg), MICROCODE1(_OUT(reg) | ALS(INC_A) | _ALi), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing AND reg <- reg & Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(AND, reg), MICROCODE2(_OUT(reg) | ALS(A_AND_B) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing OR reg <- reg | Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(OR, reg), MICROCODE2(_OUT(reg) | ALS(A_OR_B) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing ZERO reg instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(ZERO, reg), MICROCODE2(_OUT(reg) | ALS(ZERO_0) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing ONE reg instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(ONE, reg), MICROCODE2(_OUT(reg) | ALS(ONE_0) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing XOR reg <- reg ^ Rb instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(XOR, reg), MICROCODE2(_OUT(reg) | ALS(A_XOR_B) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.print("Writing NOT reg <- !reg instructions .");
  for (uint8_t reg = Ra; reg <= Rd; reg++) {
    write_instruction(ALU_OPCODE(NOT, reg), MICROCODE2(_OUT(reg) | ALS(NOT_A) | _ALi, _IN(reg) | _ALo), rom_no);
  }
  Serial.println(". done.");
  Serial.println("Written 64 ALU instructions.");
}
#endif

// Programming the ALU Special instructions
#ifdef INS_ALU_SP
void write_ALU_SP_instructions(uint8_t rom_no) {
  Serial.print("Writing INC SP <- SP + 1 and DCR SP <- SP - 1 instructions .");
    write_instruction(OPCODE(LOD, SPid, Ra), MICROCODE2(_OUT(Sp) | ALS(INC_A) | _Cin | _ALi, _IN(Sp) | _ALo), rom_no); 
    write_instruction(OPCODE(LOD, SPid, Rb), MICROCODE2(_OUT(Sp) | ALS(DCR_A) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing SHL|ROL Sp <- Sp instructions .");
    write_instruction(OPCODE(LOD, SPid, Rc), MICROCODE2(_OUT(Sp) | ALS(SHL_A) | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, Rd), false, MICROCODE3(_OUT(Sp) | ALS(SHL_A) | _ALi, _OUT(Sp) | ALS(SHL_A) | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, Rd), true, MICROCODE3(_OUT(Sp) | ALS(SHL_A) | _ALi, _OUT(Sp) | ALS(SHL_A) | _Cin | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing ADD|ADDC Sp <- Sp + Rb instructions .");
    write_instruction(OPCODE(LOD, SPid, Sp), MICROCODE2(_OUT(Sp) | ALS(A_PLUS_B) | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, Pc), false, MICROCODE2(_OUT(Sp) | ALS(A_PLUS_B) | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, Pc), true, MICROCODE2(_OUT(Sp) | ALS(A_PLUS_B) | _Cin | _ALi, _IN(Sp) | _ALo), rom_no);    
  Serial.println(".");
  Serial.print("Writing SUB|SUBC Sp <- Sp - Rb instructions .");
    write_instruction(OPCODE(LOD, SPid, SPid), MICROCODE2(_OUT(Sp) | ALS(A_MINUS_B) | _Cin | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, IMM), false, MICROCODE2(_OUT(Sp) | ALS(A_MINUS_B) | _ALi, _IN(Sp) | _ALo), rom_no);
    write_carrycond_instruction(OPCODE(LOD, SPid, IMM), true, MICROCODE2(_OUT(Sp) | ALS(A_MINUS_B) | _Cin | _ALi, _IN(Sp) | _ALo), rom_no);  
  Serial.println(".");
  Serial.print("Writing CMP Sp, Rb instruction .");
    write_instruction(OPCODE(LOD, IMM, Ra), MICROCODE1(_OUT(Sp) | ALS(A_MINUS_B) | _ALi), rom_no);
  Serial.println(".");
  Serial.print("Writing TST Sp instruction .");
    write_instruction(OPCODE(LOD, IMM, Rb), MICROCODE1(_OUT(Sp) | ALS(INC_A) | _ALi), rom_no);
  Serial.println(".");
  Serial.print("Writing AND Sp <- Sp & Rb instruction .");
    write_instruction(OPCODE(LOD, IMM, Rc), MICROCODE2(_OUT(Sp) | ALS(A_AND_B) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing OR Sp <- Sp | Rb instruction .");
    write_instruction(OPCODE(LOD, IMM, Rd), MICROCODE2(_OUT(Sp) | ALS(A_OR_B) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing ZERO Sp instruction .");
    write_instruction(OPCODE(LOD, IMM, Sp), MICROCODE2(_OUT(Sp) | ALS(ZERO_0) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing ONE Sp instruction .");
    write_instruction(OPCODE(LOD, IMM, Pc), MICROCODE2(_OUT(Sp) | ALS(ONE_0) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing XOR Sp <- Sp ^ Rb instruction .");
    write_instruction(OPCODE(LOD, IMM, SPid), MICROCODE2(_OUT(Sp) | ALS(A_XOR_B) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(".");
  Serial.print("Writing NOT Sp <- !Sp instruction .");
    write_instruction(OPCODE(LOD, IMM, IMM), MICROCODE2(_OUT(Sp) | ALS(NOT_A) | _ALi, _IN(Sp) | _ALo), rom_no);
  Serial.println(". done.");
  Serial.println("Written 16 Special ALU instructions.");
}
#endif

#ifdef CHECK_COVERAGE
char buf[80];
#endif

void setup() {
  Serial.begin(115200);
  EEPROG.setInit();
  Serial.print("About to program microcode EEPROM no. ");
  Serial.print(ROM_NO);
  Serial.print(". Press 'y' to continue ... ");
  while (Serial.available() <= 0);
  char answer = Serial.read();
  Serial.println(answer);
  if (answer == 'y') {
    #ifdef ERASE
    EEPROG.eraseALL();
    #endif
   
    #ifdef CHECK_COVERAGE
    for (uint16_t c=0; c <1024; c++) {
        write_mask[c] = 0;
    }
    #endif
    
    EEPROG.setWrite();
    #ifdef INS_MOV
    write_MOVs(ROM_NO);
    #endif

    #ifdef INS_LOD
    write_LODs(ROM_NO);
    #endif

    #ifdef INS_STO
    write_STOs(ROM_NO);
    #endif

    #ifdef INS_ALU
    write_ALU_instructions(ROM_NO);
    #endif

    #ifdef INS_ALU_SP
    write_ALU_SP_instructions(ROM_NO);
    #endif
    EEPROG.setStandby();

    #ifdef DUMP
    EEPROG.printContents();
    #endif

    #ifdef CHECK_COVERAGE
    Serial.println("Output mask");
    for (int c=0; c < 32; c+=16) {
      sprintf(buf, "%02x %02x %02x %02x %02x %02x %02x %02x  %02x %02x %02x %02x %02x %02x %02x %02x",
      write_mask[c], write_mask[c+1], write_mask[c+2], write_mask[c+3], write_mask[c+4], write_mask[c+5], write_mask[c+6], write_mask[c+7],
      write_mask[c+8], write_mask[c+9], write_mask[c+10], write_mask[c+11], write_mask[c+12], write_mask[c+13], write_mask[c+14], write_mask[c+15]);
      Serial.println(buf);
    }
    #endif
  }  
  Serial.println("Have a nice day.");
}

void loop() {
}